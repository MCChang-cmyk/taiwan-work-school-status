"""Conservative, date-aware parser; independent of Home Assistant."""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from html.parser import HTMLParser

from .const import CITIES, TAIPEI


class ParseError(ValueError):
    """The response is not a recognizable DGPA announcement."""


def normalize(text: str) -> str:
    return re.sub(r"\s+", "", text).replace("台", "臺")


class _TableParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.rows: list[list[str]] = []
        self.row: list[str] | None = None
        self.cell: list[str] | None = None
        self.text: list[str] = []

    def handle_starttag(self, tag, attrs):
        if tag == "tr":
            self.row = []
        elif tag in ("td", "th") and self.row is not None:
            self.cell = []
        elif tag in ("br", "p", "div") and self.cell is not None:
            self.cell.append("\n")

    def handle_endtag(self, tag):
        if tag in ("td", "th") and self.cell is not None:
            self.row.append("".join(self.cell))
            self.cell = None
        elif tag == "tr" and self.row is not None:
            self.rows.append(self.row)
            self.row = None
        elif tag in ("p", "div") and self.cell is not None:
            self.cell.append("\n")

    def handle_data(self, data):
        self.text.append(data)
        if self.cell is not None:
            self.cell.append(data)


@dataclass(frozen=True)
class Report:
    report_date: date
    source_updated: datetime | None
    announcements: dict[str, tuple[str, ...]]
    no_announcements: bool = False

    def combined_status(self, city: str, target: date) -> str:
        """Combine work/school without hiding mixed or incomplete announcements."""
        work = self.status(city, target, "上班")
        school = self.status(city, target, "上課")
        if work == school:
            return work
        if "undetermined" in (work, school):
            return "undetermined"
        if "partial" in (work, school):
            return "partial"
        if work == "suspended" and school == "normal":
            return "work_only"
        if work == "normal" and school == "suspended":
            return "school_only"
        return "undetermined"

    def status(self, city: str, target: date, kind: str) -> str:
        """Never infer full-city closure from a scoped or timed announcement."""
        # Product policy: an explicitly validated empty official page means
        # normal operation for the dated page and its following day only.
        if self.no_announcements and self.report_date <= target <= self.report_date + timedelta(
            days=1
        ):
            return "normal"
        full: set[str] = set()
        criteria: set[str] = set()
        scoped_criteria = False
        partial = False
        scoped_normal = False
        for line in self.announcements.get(city, ()):
            for segment in re.split(r"[。；;\n]+", normalize(line)):
                if not segment or _target_date(segment, self.report_date) != target:
                    continue
                # A threshold assessment is not itself a closure announcement.
                # Remove it before matching direct "停止上班" substrings.
                assessments = list(
                    re.finditer(
                        r"(已達|未達)(停止(?:上班|上課)(?:(?:及|與|、)(?:停止)?(?:上班|上課))?)標準",
                        segment,
                    )
                )
                direct = re.sub(
                    r"(已達|未達)(停止(?:上班|上課)(?:(?:及|與|、)(?:停止)?(?:上班|上課))?)標準",
                    "",
                    segment,
                )
                closed = f"停止{kind}" in direct
                normal = f"照常{kind}" in direct
                scoped = bool(
                    re.search(
                        r"[:：]|(?:上午|下午|晚上|晚間|中午|\d{1,2}[時:：]|起|部分|部份)", segment
                    )
                )
                for assessment in assessments:
                    if kind in assessment[2]:
                        if scoped:
                            scoped_criteria = True
                        else:
                            criteria.add(
                                "criteria_met" if assessment[1] == "已達" else "criteria_not_met"
                            )
                if not (closed or normal):
                    continue
                if scoped:
                    partial |= closed
                    scoped_normal |= normal
                else:
                    full.add("suspended" if closed else "normal")
        if len(full) > 1:
            return "undetermined"
        if partial or (scoped_normal and "suspended" in full):
            return "partial"
        if full:
            return next(iter(full))
        if scoped_criteria or len(criteria) > 1:
            return "undetermined"
        return next(iter(criteria), "unannounced")


def _target_date(text: str, base: date) -> date | None:
    explicit = re.search(r"(?:(\d{3,4})年)?(\d{1,2})月(\d{1,2})日", text)
    if explicit:
        year = int(explicit[1]) if explicit[1] else base.year
        if year < 1911:
            year += 1911
        try:
            result = date(year, int(explicit[2]), int(explicit[3]))
            if not explicit[1] and abs((result - base).days) > 180:
                result = result.replace(year=base.year + (1 if base.month == 12 else -1))
            return result
        except ValueError:
            return None
    if "明天" in text or "明日" in text:
        return base + timedelta(days=1)
    if "後天" in text:
        return base + timedelta(days=2)
    # Unqualified city-wide statements refer to the dated page, never fetch date.
    return base


def parse_html(html: str) -> Report:
    parser = _TableParser()
    parser.feed(html)
    text = normalize("".join(parser.text))
    header = re.search(r"(\d{3,4})年(\d{1,2})月(\d{1,2})日天然災害停止上班", text)
    if not header:
        raise ParseError("Missing announcement date")
    year = int(header[1])
    if year < 1911:
        year += 1911
    try:
        report_date = date(year, int(header[2]), int(header[3]))
        updated_match = re.search(r"更新時間[：:](\d{4}/\d{1,2}/\d{1,2})(\d{2}:\d{2}:\d{2})", text)
        updated = (
            datetime.strptime(" ".join(updated_match.groups()), "%Y/%m/%d %H:%M:%S").replace(
                tzinfo=TAIPEI
            )
            if updated_match
            else None
        )
    except ValueError as err:
        raise ParseError("Invalid announcement date") from err
    names = {normalize(name): key for key, name in CITIES.items()}
    announcements = {}
    for row in parser.rows:
        for index, cell in enumerate(row[:-1]):
            if (key := names.get(normalize(cell))) is not None:
                content = row[index + 1]
                lines = tuple(filter(None, (normalize(line) for line in content.splitlines())))
                if key in announcements:
                    raise ParseError("Duplicate county row")
                announcements[key] = lines
    # When there are no announcements DGPA replaces all county rows with a
    # single colspan cell. Accept only that explicit, dated table layout;
    # zero parsed rows alone must never turn an error page into valid data.
    empty_notice = any(
        len(row) == 1 and normalize(row[0]).rstrip("。.") == "無停班停課訊息" for row in parser.rows
    )
    if empty_notice:
        has_headers = any(
            {"縣市名稱", "是否停止上班上課情形"}.issubset({normalize(cell) for cell in row})
            for row in parser.rows
        )
        if announcements or not has_headers or updated is None:
            raise ParseError("Invalid or contradictory no-announcement table")
        return Report(
            report_date,
            updated,
            {city: ("無停班停課訊息。",) for city in CITIES},
            no_announcements=True,
        )
    # Fail closed on layout changes, error pages, and truncated downloads.
    if set(announcements) != set(CITIES):
        raise ParseError(f"Expected 22 county rows, found {len(announcements)}")
    return Report(report_date, updated, announcements)
